﻿using NUnit.Framework;
using System;

[TestFixture]
    public class TestClass
    {
        private MissionController missionController;

        [SetUp]
        public void TestInitialized()
        {
            this.missionController = new MissionController(new Army(), new WareHouse());
        }
        [Test]
        public void TestMissionControlerCountTestQueue()
        {
            //Arrange
            this.missionController.Missions.Enqueue(new Easy(23));
            this.missionController.Missions.Enqueue(new Easy(140));
            this.missionController.Missions.Enqueue(new Easy(34));
            //Act
            this.missionController.PerformMission(new Hard(78));
            //Assert
            Assert.AreEqual(3, this.missionController.Missions.Count);
        }

        [Test]
        public void TestMissionControlerFailedMissionCounter()
        {
            //Arrange
            this.missionController.Missions.Enqueue(new Easy(23));
            this.missionController.Missions.Enqueue(new Easy(140));
            this.missionController.Missions.Enqueue(new Easy(34));
            //Act
            this.missionController.FailMissionsOnHold();
            //Assert
            Assert.AreEqual(3, this.missionController.FailedMissionCounter);
        }

        [Test]
        public void TestPerformMissionMethodOnHold()
        {
            IArmy army = new Army();
            army.AddSoldier(new Corporal("Pepo", 12, 23, 2));
            army.AddSoldier(new Corporal("Ricky", 29, 29, 19));
            IWareHouse wareHouse = new WareHouse();
            wareHouse.AddWeapon("AutomaticMachine", 12);
            wareHouse.AddWeapon("Gun", 3);
            wareHouse.AddWeapon("Helmet", 5);
            wareHouse.AddWeapon("Knife", 12);
            wareHouse.AddWeapon("MachineGun", 3);
            wareHouse.AddWeapon("NightVision", 5);
            wareHouse.AddWeapon("RPG", 56);
            MissionController mc = new MissionController(army, wareHouse);

            string res = mc.PerformMission(new Easy(23));
            string result = "Mission on hold - Suppression of civil rebellion" + Environment.NewLine;


            Assert.AreEqual(result, res);
        }

        [Test]
        public void TestPerformMissionMethodCompleted()
        {
            IArmy army = new Army();
            army.AddSoldier(new Corporal("Pepo", 12, 23, 2));
            army.AddSoldier(new Corporal("Ricky", 29, 29, 20));
            IWareHouse wareHouse = new WareHouse();
            wareHouse.AddWeapon("AutomaticMachine", 12);
            wareHouse.AddWeapon("Gun", 3);
            wareHouse.AddWeapon("Helmet", 5);
            wareHouse.AddWeapon("Knife", 12);
            wareHouse.AddWeapon("MachineGun", 3);
            wareHouse.AddWeapon("NightVision", 5);
            wareHouse.AddWeapon("RPG", 56);
            MissionController mc = new MissionController(army, wareHouse);

            string res = mc.PerformMission(new Easy(23));
            string result = "Mission completed - Suppression of civil rebellion" + Environment.NewLine;


            Assert.AreEqual(result, res);
        }

        [Test]
        public void TestSuccessMissionCounter()
        {
            IArmy army = new Army();
            army.AddSoldier(new Corporal("Pepo", 12, 23, 38));
            army.AddSoldier(new Corporal("Ricky", 29, 29, 95));
            IWareHouse wareHouse = new WareHouse();
            wareHouse.AddWeapon("AutomaticMachine", 12);
            wareHouse.AddWeapon("Gun", 3);
            wareHouse.AddWeapon("Helmet", 5);
            wareHouse.AddWeapon("Knife", 12);
            wareHouse.AddWeapon("MachineGun", 3);
            wareHouse.AddWeapon("NightVision", 5);
            wareHouse.AddWeapon("RPG", 56);
            MissionController mc = new MissionController(army, wareHouse);

            string res = mc.PerformMission(new Easy(23));
 
            Assert.AreEqual(1, mc.SuccessMissionCounter);
        }

    }

