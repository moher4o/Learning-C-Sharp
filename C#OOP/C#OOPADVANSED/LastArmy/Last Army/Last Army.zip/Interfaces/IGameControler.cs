﻿
public interface IGameControler
{
    IMissionController MissionControllerField { get; }
}

