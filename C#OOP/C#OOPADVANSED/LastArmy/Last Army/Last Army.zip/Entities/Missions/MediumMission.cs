﻿
public class MediumMission : Mission
{
    private const double endurance = 50d;
    public MediumMission(string name, double score, double levelDecrement) : base(name, score, endurance, levelDecrement)
    {
    }
}

