﻿
public class HardMission : Mission
{
    private const double endurance = 80d;
    public HardMission(string name, double score, double levelDecrement) : base(name, score, endurance, levelDecrement)
    {
    }
}

