﻿
public class EasyMission : Mission
{
    private const double endurance = 20d;
    public EasyMission(string name, double score, double leverDecrement) : base(name, score, endurance, leverDecrement)
    {
    }
}

