﻿
    public class RPG : Ammunition
    {
        private const double CurrentWeight = 17.1;

        public RPG(string name)
            : base(name, CurrentWeight)
        {
        }
    }
