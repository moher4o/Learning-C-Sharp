﻿public class AutomaticMachine : Ammunition
{
    private const double CurrentWeight = 6.3;

    public AutomaticMachine(string name)
        : base(name, CurrentWeight)
    {
    }
}