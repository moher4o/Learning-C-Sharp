﻿
public class BulletproofVest : Ammunition
{
    private const double CurrentWeight = 3.4;

    public BulletproofVest(string name)
        : base(name, CurrentWeight)
    {
    }
}
