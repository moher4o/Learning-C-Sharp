﻿    public class MachineGun : Ammunition
    {
        private const double CurrentWeight = 10.6;

        public MachineGun(string name)
            : base(name, CurrentWeight)
        {
        }
    }
