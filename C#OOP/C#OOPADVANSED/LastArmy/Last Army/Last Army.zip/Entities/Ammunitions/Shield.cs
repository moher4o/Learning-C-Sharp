﻿    public class Shield : Ammunition
{
        private const double CurrentWeight = 3.7;

        public Shield(string name)
            : base(name, CurrentWeight)
        {
        }
    }
