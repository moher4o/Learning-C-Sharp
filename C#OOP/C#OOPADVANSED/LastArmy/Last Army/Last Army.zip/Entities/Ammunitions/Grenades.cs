﻿
public class Grenades : Ammunition
{
    private const double CurrentWeight = 1.0;

    public Grenades(string name)
        : base(name, CurrentWeight)
    {
    }
}
