﻿public class Knife : Ammunition
{
    private const double CurrentWeight = 0.4;

    public Knife(string name)
        : base(name, CurrentWeight)
    {
    }
}
