﻿
public class LastArmyMain
{
    static void Main()
    {
        
        IArmy army = new Army();
        IWareHouse wareHouse = new WareHouse();
        IMissionController missioncontroler = new MissionController(army, wareHouse);
        //IGameControler gameControler = new GameController(army,wareHouse,missioncontroler);
        IReader reader = new ConsoleReader();
        IWriter writer = new ConsoleWriter();
        IEngine engine = new Engine(missioncontroler, wareHouse, army, reader, writer);


        engine.Run();
        //var input = ConsoleReader.ReadLine();
        //var gameController = new GameController();
        //var result = new StringBuilder();

        //while (!input.Equals("Enough! Pull back!"))
        //{
        //    try
        //    {
        //        gameController.GiveInputToGameController(input);
        //    }
        //    catch (ArgumentException arg)
        //    {
        //        result.AppendLine(arg.Message);
        //    }
        //    input = ConsoleReader.ReadLine();
        //}

        //gameController.RequestResult(result);
        //ConsoleWriter.WriteLine(result.ToString());
    }
}
