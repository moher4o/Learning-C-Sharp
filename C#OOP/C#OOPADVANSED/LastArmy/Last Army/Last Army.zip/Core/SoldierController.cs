﻿public class SoldierController
{

}
