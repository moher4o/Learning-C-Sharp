﻿public static class AmmunitionsController
{

}
