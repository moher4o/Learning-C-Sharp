﻿using Emergency_Skeleton.Core;

namespace Emergency_Skeleton
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
