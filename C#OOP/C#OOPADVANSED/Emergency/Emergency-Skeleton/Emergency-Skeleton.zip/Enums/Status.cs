﻿namespace Emergency_Skeleton.Enums
{
    public enum Status
    {
        NonSpecial,
        Special
    }
}
