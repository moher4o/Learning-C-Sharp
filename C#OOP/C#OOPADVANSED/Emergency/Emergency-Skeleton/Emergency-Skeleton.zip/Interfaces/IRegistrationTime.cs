﻿namespace Emergency_Skeleton.Interfaces
{
   public interface IRegistrationTime
   {
       string ToString();
   }
}
