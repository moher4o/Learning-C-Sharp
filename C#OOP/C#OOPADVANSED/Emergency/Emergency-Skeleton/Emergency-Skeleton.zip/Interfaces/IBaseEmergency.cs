﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Emergency_Skeleton.Enums;
using Emergency_Skeleton.Utils;

namespace Emergency_Skeleton.Interfaces
{
   public interface IBaseEmergency
    {
        int Trouble { get; }
        string Description { get; }
        EmergencyLevel EmergencyLevel { get; }
        IRegistrationTime RegistrationTime { get; }
    }
}
