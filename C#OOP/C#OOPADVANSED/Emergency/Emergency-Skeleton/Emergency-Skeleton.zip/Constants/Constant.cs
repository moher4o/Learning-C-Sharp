﻿namespace Emergency_Skeleton.Constants
{
   public class Constant
    {
        public const string EndOFGame = "EmergencyBreak";
    }
}
