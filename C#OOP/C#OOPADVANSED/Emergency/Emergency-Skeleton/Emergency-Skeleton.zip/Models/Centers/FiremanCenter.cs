﻿namespace Emergency_Skeleton.Models.Centers
{
   public class FiremanCenter : BaseEmergencyCenter
    {
        public FiremanCenter(string name, int amountOfMaximumEmergencies) : base(name, amountOfMaximumEmergencies)
        {
        }
    }
}
