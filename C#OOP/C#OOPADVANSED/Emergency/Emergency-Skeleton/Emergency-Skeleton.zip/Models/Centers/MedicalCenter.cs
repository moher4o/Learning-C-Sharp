﻿namespace Emergency_Skeleton.Models.Centers
{
   public class MedicalCenter : BaseEmergencyCenter
    {
        public MedicalCenter(string name, int amountOfMaximumEmergencies) : base(name, amountOfMaximumEmergencies)
        {
        }
    }
}
