﻿namespace Emergency_Skeleton.Models.Centers
{
   public class PoliceCenter : BaseEmergencyCenter
    {
        public PoliceCenter(string name, int amountOfMaximumEmergencies) : base(name, amountOfMaximumEmergencies)
        {
        }
    }
}
